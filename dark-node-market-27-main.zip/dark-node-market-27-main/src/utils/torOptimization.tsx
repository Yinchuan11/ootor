// Tor/.onion domain optimization utilities

/**
 * Tor-optimized fetch function with enhanced error handling and retries
 */
export const torFetch = async (url: string, options: RequestInit = {}, retries: number = 3): Promise<Response> => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000); // 30 seconds

  const defaultOptions: RequestInit = {
    headers: {
      'Accept': 'application/json',
      'User-Agent': 'Oracle-Market/1.0',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      ...options.headers
    },
    signal: controller.signal,
    ...options
  };

  try {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const response = await fetch(url, defaultOptions);
        
        if (!response.ok && response.status >= 500 && attempt < retries) {
          // Retry on server errors
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          continue;
        }
        
        clearTimeout(timeout);
        return response;
      } catch (error) {
        if (attempt === retries) {
          throw error;
        }
        
        // Exponential backoff for retries
        await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)));
      }
    }
    
    throw new Error('Max retries exceeded');
  } finally {
    clearTimeout(timeout);
  }
};

/**
 * Check if running on Tor network
 */
export const isTorNetwork = (): boolean => {
  return window.location.hostname.endsWith('.onion');
};

/**
 * Get optimized CSP headers for Tor
 */
export const getTorCSPHeaders = (): string => {
  const baseCSP = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "connect-src 'self' https://api.coingecko.com",
    "frame-src 'none'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'"
  ];
  
  // More restrictive for .onion domains
  if (isTorNetwork()) {
    return baseCSP
      .map(directive => directive === "connect-src 'self' https://api.coingecko.com" 
        ? "connect-src 'self'" 
        : directive)
      .join('; ');
  }
  
  return baseCSP.join('; ');
};

/**
 * Disable features that might compromise anonymity
 */
export const initTorOptimizations = () => {
  if (isTorNetwork()) {
    // Disable WebRTC if possible
    if ('RTCPeerConnection' in window) {
      try {
        (window as any).RTCPeerConnection = undefined;
      } catch (e) {
        console.log('Could not disable WebRTC');
      }
    }
    
    // Disable geolocation
    if ('geolocation' in navigator) {
      try {
        Object.defineProperty(navigator, 'geolocation', {
          value: undefined,
          writable: false
        });
      } catch (e) {
        console.log('Could not disable geolocation');
      }
    }
    
    // Disable device motion/orientation sensors
    ['DeviceMotionEvent', 'DeviceOrientationEvent'].forEach(eventType => {
      if (eventType in window) {
        try {
          (window as any)[eventType] = undefined;
        } catch (e) {
          console.log(`Could not disable ${eventType}`);
        }
      }
    });
  }
};

/**
 * Get recommended meta tags for Tor hosting
 */
export const getTorMetaTags = () => {
  return [
    { name: 'referrer', content: 'no-referrer' },
    { name: 'robots', content: 'noindex, nofollow, noarchive, nosnippet, noimageindex' },
    { httpEquiv: 'Content-Security-Policy', content: getTorCSPHeaders() },
    { httpEquiv: 'X-Content-Type-Options', content: 'nosniff' },
    { httpEquiv: 'X-Frame-Options', content: 'DENY' },
    { httpEquiv: 'X-XSS-Protection', content: '1; mode=block' },
    { httpEquiv: 'Strict-Transport-Security', content: 'max-age=31536000; includeSubDomains' }
  ];
};