import { useState, useEffect, useCallback, useRef } from 'react';
import { torFetch, isTorNetwork } from '@/utils/torOptimization';

interface CryptoPrices {
  btc: number | null;
  ltc: number | null;
  lastUpdated: number | null;
  loading: boolean;
  error: string | null;
}

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const RETRY_DELAY = 2000; // 2 seconds
const MAX_RETRIES = 3;

// Fallback prices in case external APIs fail
const FALLBACK_PRICES = {
  btc: 45000, // EUR
  ltc: 100    // EUR
};

export const useCryptoPrices = () => {
  const [prices, setPrices] = useState<CryptoPrices>({
    btc: null,
    ltc: null,
    lastUpdated: null,
    loading: true,
    error: null
  });
  
  const retryCountRef = useRef(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const fetchPricesWithFallback = useCallback(async () => {
    try {
      setPrices(prev => ({ ...prev, loading: true, error: null }));

      // Skip external API calls on Tor network for better anonymity
      if (isTorNetwork()) {
        const cached = getCachedPrices();
        if (cached.btc && cached.ltc) {
          setPrices({
            btc: cached.btc,
            ltc: cached.ltc,
            lastUpdated: cached.lastUpdated || Date.now(),
            loading: false,
            error: 'Using cached prices (Tor network)'
          });
          return;
        } else {
          // Use fallback prices on Tor if no cache
          setPrices({
            btc: FALLBACK_PRICES.btc,
            ltc: FALLBACK_PRICES.ltc,
            lastUpdated: Date.now(),
            loading: false,
            error: 'Using fallback prices (Tor network)'
          });
          return;
        }
      }

      // Try primary API (CoinGecko) for clearnet
      const [btcResponse, ltcResponse] = await Promise.allSettled([
        torFetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=eur'),
        torFetch('https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=eur')
      ]);

      let btcPrice = null;
      let ltcPrice = null;

      // Process BTC response
      if (btcResponse.status === 'fulfilled' && btcResponse.value.ok) {
        const btcData = await btcResponse.value.json();
        btcPrice = btcData.bitcoin?.eur;
      }

      // Process LTC response
      if (ltcResponse.status === 'fulfilled' && ltcResponse.value.ok) {
        const ltcData = await ltcResponse.value.json();
        ltcPrice = ltcData.litecoin?.eur;
      }

      // If any price failed, use cached or fallback
      if (!btcPrice || !ltcPrice) {
        const cached = getCachedPrices();
        if (!btcPrice) {
          btcPrice = cached.btc || FALLBACK_PRICES.btc;
        }
        if (!ltcPrice) {
          ltcPrice = cached.ltc || FALLBACK_PRICES.ltc;
        }
      }

      const newPrices = {
        btc: btcPrice,
        ltc: ltcPrice,
        lastUpdated: Date.now(),
        loading: false,
        error: null
      };

      setPrices(newPrices);
      cachePrices(newPrices);
      retryCountRef.current = 0;

    } catch (error) {
      console.error('Error fetching crypto prices:', error);
      
      // Try to use cached prices
      const cached = getCachedPrices();
      if (cached.btc && cached.ltc && cached.lastUpdated && (Date.now() - cached.lastUpdated < CACHE_DURATION * 2)) {
        setPrices({
          btc: cached.btc,
          ltc: cached.ltc,
          lastUpdated: cached.lastUpdated,
          loading: false,
          error: 'Using cached prices'
        });
      } else {
        // Use fallback prices as last resort
        setPrices({
          btc: FALLBACK_PRICES.btc,
          ltc: FALLBACK_PRICES.ltc,
          lastUpdated: Date.now(),
          loading: false,
          error: 'Using fallback prices'
        });
      }

      // Retry with exponential backoff
      if (retryCountRef.current < MAX_RETRIES) {
        retryCountRef.current++;
        const delay = RETRY_DELAY * Math.pow(2, retryCountRef.current - 1);
        timeoutRef.current = setTimeout(() => {
          fetchPricesWithFallback();
        }, delay);
      }
    }
  }, []);

  const getCachedPrices = (): Partial<CryptoPrices> => {
    try {
      const cached = localStorage.getItem('crypto-prices-cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.lastUpdated && (Date.now() - parsed.lastUpdated < CACHE_DURATION)) {
          return parsed;
        }
      }
    } catch (error) {
      console.error('Error reading cached prices:', error);
    }
    return {};
  };

  const cachePrices = (prices: CryptoPrices) => {
    try {
      localStorage.setItem('crypto-prices-cache', JSON.stringify({
        btc: prices.btc,
        ltc: prices.ltc,
        lastUpdated: prices.lastUpdated
      }));
    } catch (error) {
      console.error('Error caching prices:', error);
    }
  };

  const refreshPrices = useCallback(() => {
    retryCountRef.current = 0;
    fetchPricesWithFallback();
  }, [fetchPricesWithFallback]);

  useEffect(() => {
    // Check if we have valid cached prices first
    const cached = getCachedPrices();
    if (cached.btc && cached.ltc && cached.lastUpdated) {
      setPrices({
        btc: cached.btc,
        ltc: cached.ltc,
        lastUpdated: cached.lastUpdated,
        loading: false,
        error: null
      });
    }

    // Fetch fresh prices
    fetchPricesWithFallback();

    // Set up periodic refresh
    const interval = setInterval(() => {
      fetchPricesWithFallback();
    }, CACHE_DURATION);

    return () => {
      clearInterval(interval);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [fetchPricesWithFallback]);

  return {
    ...prices,
    refreshPrices
  };
};