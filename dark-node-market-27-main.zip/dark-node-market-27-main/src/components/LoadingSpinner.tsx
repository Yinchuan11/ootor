import { RefreshCw } from 'lucide-react';

interface LoadingSpinnerProps {
  text?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const LoadingSpinner = ({ text = 'Loading...', size = 'md' }: LoadingSpinnerProps) => {
  const sizeClasses = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4', 
    lg: 'h-6 w-6'
  };

  return (
    <div className="flex items-center gap-2 text-muted-foreground">
      <RefreshCw className={`animate-spin ${sizeClasses[size]}`} />
      <span className="text-sm">{text}</span>
    </div>
  );
};