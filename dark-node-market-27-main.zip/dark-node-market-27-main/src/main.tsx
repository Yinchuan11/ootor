import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { initTorOptimizations } from './utils/torOptimization'

// Initialize Tor optimizations
initTorOptimizations();

createRoot(document.getElementById("root")!).render(<App />);
